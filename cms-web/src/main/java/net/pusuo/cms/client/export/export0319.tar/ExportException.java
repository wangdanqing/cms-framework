/*
 * Created on 2005-9-6
 *
 * TODO To change the template for this generated file go to
 * Window - Preferences - Java - Code Style - Code Templates
 */
package com.hexun.cms.client.export;

/**
 * @author huaiwenyuan
 *
 * TODO To change the template for this generated type comment go to
 * Window - Preferences - Java - Code Style - Code Templates
 */
public class ExportException extends Exception {
 
    /**
     * 
     */
    public ExportException() {
        super();
        // TODO Auto-generated constructor stub
    }

    /**
     * @param message
     */
    public ExportException(String message) {
        super(message);
        // TODO Auto-generated constructor stub
    }

    /**
     * @param message
     * @param cause
     */
    public ExportException(String message, Throwable cause) {
        super(message, cause);
        // TODO Auto-generated constructor stub
    }

    /**
     * @param cause
     */
    public ExportException(Throwable cause) {
        super(cause);
        // TODO Auto-generated constructor stub
    }

}
